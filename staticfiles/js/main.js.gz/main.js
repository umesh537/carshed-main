$("button").click(() => $(".carousel").carousel("next"));


// $(function() {

// 	$('.owl-carousel').owlCarousel({

//     loop:true,
//     margin:0,
//     nav:true,
//     items: 3,
//     smartSpeed: 1000,
//     autoplay: true,
//     autoplayHoverPause: true,
//     navText: ['<span class="icon-keyboard_arrow_left">', '<span class="icon-keyboard_arrow_right">']
// 	})

	
// })